using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemCollectScript : MonoBehaviour
{
    private int cherries = 0;
    [SerializeField] private AudioSource collectSoundEffect;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if( collision.gameObject.CompareTag("Collectable Item") )
        {
            collectSoundEffect.Play();
            Destroy(collision.gameObject);
            cherries++;
        }
    }
    
}
